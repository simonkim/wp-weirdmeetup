<?php
/**
 * The template for displaying the footer.
 *
 * Contains footer content and the closing of the
 * #main and #page div elements.
 *
 * @package WordPress
 * @subpackage Authentic Themes
 * @since 1.0
 */
?>

			</div><!-- /site-content -->
        </div><!-- /main-content -->
    </div><!-- /wrap -->

<?php att_hook_site_after(); ?>

<?php wp_footer(); ?>
</body>
</html>