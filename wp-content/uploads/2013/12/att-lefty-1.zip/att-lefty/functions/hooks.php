<?php
/**
 * Add some useful hooks to main theme elemensts
 */


function att_hook_site_before() {
	do_action( 'att_hook_site_before' );
}

function att_hook_site_after() {
	do_action( 'att_hook_site_after' );
}