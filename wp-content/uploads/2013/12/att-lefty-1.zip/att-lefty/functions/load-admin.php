<?php
/**
 * Load Admin Panel & create fallback options
 *
 * @package WordPress
 * @subpackage Authentic Themes
 * @since 1.0
 */
if ( !function_exists( 'optionsframework_init' ) ) {
	define( 'OPTIONS_FRAMEWORK_DIRECTORY', get_template_directory_uri() . '/admin/' );
	require_once ( get_template_directory() . '/admin/options-framework.php' );
}
if ( !function_exists( 'of_get_option' ) ) {
	function of_get_option($name, $default = false ) {
		$optionsframework_settings = get_option( 'optionsframework' );
		$option_name = $optionsframework_settings['id'];
		if ( get_option($option_name) ) {
			$options = get_option($option_name);
		}
		if ( isset($options[$name]) ) {
			return $options[$name];
		} else {
			return $default;
		}
	}
}